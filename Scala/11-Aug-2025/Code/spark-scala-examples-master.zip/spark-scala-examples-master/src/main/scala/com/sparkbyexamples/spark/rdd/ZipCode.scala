package com.sparkbyexamples.spark.rdd

case class ZipCode(recordNumber:Int,zipCode:String,city:String,state:String)


