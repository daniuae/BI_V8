package example
//
//@main def main(args: String*): Unit =
//  println(s"Hello ${args.mkString}")
object Main {
  def main(args: Array[String]): Unit = {
   println("Hello, Spark!")
    //println(s"Hello ${args.mkString}")
  }
}
