package example

class ExampleSuite extends munit.FunSuite:

  test("addition") {
    assert(1 + 1 == 2)
  }
end ExampleSuite
