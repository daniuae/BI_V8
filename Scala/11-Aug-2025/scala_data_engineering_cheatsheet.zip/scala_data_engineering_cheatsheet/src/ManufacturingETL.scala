
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object ManufacturingETL {
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder()
      .appName("Manufacturing ETL")
      .master("local[*]")
      .getOrCreate()

    import spark.implicits._

    // Extract
    val productionDF = spark.read
      .option("header", true)
      .option("inferSchema", true)
      .csv("data/plant_production.csv")

    // Transform
    val transformedDF = productionDF
      .withColumn("production_per_hour", $"units_produced" / 8)
      .filter($"units_produced" > 100)
      .withColumn("shift_time", when($"shift" === 1, "Morning")
                                .when($"shift" === 2, "Afternoon")
                                .otherwise("Night"))

    // Load
    transformedDF.write
      .mode("overwrite")
      .option("header", true)
      .csv("output/processed_production")

    spark.stop()
  }
}
